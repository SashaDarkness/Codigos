package Desafio03;
public class questao02AlfabetoCifrado2 {
    public static void main(String[] args){
        int cont = 1;
        for (int i = 97; i < 122; i++ ) {
            if (i + cont  <= 122 ) { //A = B, B = D, C = F, D = H...
                System.out.println( (char) i + " => " + (char) (i + cont++) );
            }
        }
    }
}
